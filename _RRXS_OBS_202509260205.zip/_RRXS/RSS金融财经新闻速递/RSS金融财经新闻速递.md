https://www.nbd.com.cn/rss/finance.xml      # 每经
https://rss.caixin.com/finance.xml          # 财新
https://feeds.bloomberg.com/markets/news.rss # 彭博
https://wallstreetcn.com/rss/finance.xml    # 华尔街见闻
https://www.pbc.gov.cn/rss/yw.rss           # 央行
https://www.csrc.gov.cn/rss/yw.rss          # 证监会

http://rss.sina.com.cn/finance/jjxw.xml  #新浪财经