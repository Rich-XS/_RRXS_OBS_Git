
# 阿里云 
## 解析 https://dnsnext.console.aliyun.com/authoritative/domains/rrxs.xyz

# SSL证书 E:\Software\Tools_Internet\_rrxs.xyz


# 腾讯云
## 静态网站托管 https://console.cloud.tencent.com/tcb/hosting/index?envId=lowcode-8g07gv0h11b9486e&rid=4&moduleName=&tabId=config
